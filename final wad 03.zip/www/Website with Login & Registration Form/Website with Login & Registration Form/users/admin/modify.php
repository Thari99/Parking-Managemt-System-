<?php

session_start();


// Your database connection settings
include("connection.php");


// Function to sanitize input data to prevent SQL injection
function sanitizeInput($input) {
    return htmlspecialchars(trim($input));
}

// Function to hash the password
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Make sure the form was submitted with the required fields
    if (isset($_POST['current_password'], $_POST['new_password'], $_POST['confirm_password'], $_POST['admin_id'])) {
        // Sanitize input data
        $currentPassword = sanitizeInput($_POST['current_password']);
        $newPassword = sanitizeInput($_POST['new_password']);
        $confirmPassword = sanitizeInput($_POST['confirm_password']);
        $username_id = $_POST['Admin_id'];


        // Validate that the new password and confirmation match
        if ($newPassword !== $confirmPassword) {
            $error = "New password and confirmation do not match.";
        } else {
            // Check if the current password matches the one stored in the database
            $db = new PDO("mysql:host=$host;dbname=$database", $username, $password);
            //$user_id = $_SESSION['Admin_id'];
            $query = "SELECT ad_password FROM admin WHERE ad_password = :currentPassword";
            $statement = $db->prepare($query);
            $statement->bindParam(':currentPassword', $currentPassword, PDO::PARAM_STR);
            $statement->execute();
            $result = $statement->fetch(PDO::FETCH_ASSOC);

            if (password_verify($currentPassword, $result['ad_password'])) {
                // Hash the new password
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update the user's password in the database
                $updateQuery = "UPDATE admin SET ad_password = :password WHERE id = :user_id";
                $updateStatement = $db->prepare($updateQuery);
                $updateStatement->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
                $updateStatement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $updateStatement->execute();

                // Password successfully changed, you can redirect to a success page or update the user interface
                header("Location:change_password11.php?S=1");
                exit();
            } else {
                header("Location:change_password11.php?S=2");
            }
        }
    } else {
        header("Location:change_password11.php?S=3");
    }
}
?>