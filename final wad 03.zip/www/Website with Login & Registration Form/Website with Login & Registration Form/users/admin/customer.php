<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="employee.css">
        <script></script>
        <title>Document</title>
    </head>
    <body>
        <header>
            <h1>Customer Details</h1>
        </header>
        <?php
        include("connection.php");

        ?>
        <main>
            <br>
            <table class="employee_data">
                <tr class="table_row">

                    <th> Id</th>
                    <th> Name</th>
                    <th>username</th>
                    <th>TP</th>
                </tr>
                <?php
                $sql = "SELECT cu_ID, cu_fullname, cu_username, cu_mobileNo FROM customer";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["cu_ID"] . "</td><td>" . $row["cu_fullname"] . "</td><td>" . $row["cu_username"] . "</td><td>" . $row["cu_mobileNo"]."</td>";
                    }
                }
                ?>
        </main>
         <footer>
            <p>Developed by <a href="#">Group 6;</a></p>
        </footer>
    </body>
</html>