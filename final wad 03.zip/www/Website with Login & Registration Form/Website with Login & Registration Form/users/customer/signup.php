<?php
include("connection.php");

if(isset($_POST['submit'])) {

    $fullname = $_POST['fullname'] ;
    $username= mysqli_real_escape_string($conn,$_POST['username']);
    $mnumber= mysqli_real_escape_string($conn,$_POST['mnumber']);
    $password= mysqli_real_escape_string($conn,$_POST['pass']);
    $conpass= mysqli_real_escape_string($conn,$_POST['cpass']);

    

    $sql = "select * from customer where cu_username='$username'";
    $result = mysqli_query($conn,$sql);
    $count_username = mysqli_num_rows($result);

    $sql = "select * from customer where cu_mobileNo='$mnumber'";
    $result = mysqli_query($conn,$sql);
    $count_mnumber = mysqli_num_rows($result);

    if($count_username==0 & $count_mnumber==0) {
        if($password==$conpass) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO customer(cu_fullname,cu_username,cu_mobileNo,cu_password) VALUES('$fullname','$username','$mnumber','$hash')";
            $result = mysqli_query($conn,$sql);
            if($result) {
                header("Location:user.php");
            }
        }

    }
    else {
        if($count_username==0>0){
            echo '<script>
            window.location.href="user.php";
            alert("username already exists!");         
            </script>';
        }

        if($count_mnumber==0>0){
            echo '<script>
            window.location.href="user.php";
            alert("mobilenumber already exists!");         
            </script>';
        }

        
    }


}
?>