<?php
include("connection.php");

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['pass'];

    // Retrieve the hashed password from the database
    $sql = "SELECT cu_password FROM customer WHERE cu_username = '$username'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $hashed_password = $row['cu_password'];

        // Debug: Display hashed password retrieved from the database
        echo "Hashed password from database: $hashed_password<br>";

        // Compare the entered password with the hashed password
        if (password_verify($password, $hashed_password)) {
            // Passwords match, user is logged in
            header("Location: index.php");
        } else {
            // Incorrect password
            echo "Passwords do not match.<br>";
           
        }
    } else {
        // User not found
        echo "User not found.<br>";
    }
}
?>
