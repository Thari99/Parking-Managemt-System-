
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="change_password.css">
    <script></script>
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Modify Admin Password</h1>
    </header>
    <main>
        <form class="form_class" action="modify.php" method="post" >
            <div class="form_div">
                <label for="current_password">Admin_id</label>
                <input type="text" class="field_class" name="Admin_id" id="Admin_id" required> 
                
                <label for="current_password">Current Password</label>
                <input type="password" class="field_class" name="current_password" id="current_password" required>
               
                <label for="new_password">New Password:</label>
                <input type="password" class="field_class" name="new_password" id="new_password" required>
                
                <label for="confirm_password">Re-Enter New Password:</label>
                <input type="password" class="field_class" name="confirm_password" id="confirm_password" required>
                
                <button class="submit_class" type="submit" >Modify</button>
            </div>
        </form>
        <?php
                if (isset($_GET["S"])) {
                    if ($_GET["S"] == 1) {
                        echo "Delete Successful";
                    } elseif ($_GET["S"] == 2) {
                        echo "Can't Find Admin";
                    }
                    elseif ($_GET["S"] == 3) {
                        echo "Please fill in all the required fields.";
                    }
                }
                ?>
    </main>
    <footer>
        <p>Developed by <a href="#">Group 6;</a></p>
    </footer>
</body>
</html>