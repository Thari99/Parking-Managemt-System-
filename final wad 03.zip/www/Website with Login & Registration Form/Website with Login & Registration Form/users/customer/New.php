<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Plan Form</title>
    <link rel="stylesheet" href="newCascadeStyleSheet.css">
</head>
<body>
    <div class="Payment Plan Form">
        <h1>Payment Plan Form</h1>
        <form>
        <form action="indexp.php" method="POST">
            <label for="Vehical type">Vehical type</label>
            <select name="Vehical type" id="Vehical type">
                <option value="car">Car</option>
                <option value="van">Van</option>
                <option value="jeep">Jeep</option>
                <option value="threeweel"Threeweel</option>
            </select>
            <label for="Time duration">Time duration</label>
            <select name="Time duration" id="Time duration"
               <option value="at half an hour">At half an hour</option>
                <option value="at one hour">At one hour</option>
                <option value="grater than one hour">Grater than one hour</option>
                </select>
                    <label for="Payment fee">Payment fee</label>
                    <select name="Payment fee" id="Payment fee">
                        <option value="rs.100">RS.100</option>
                        <option value="rs.200">RS.200</option>
                        <option value="rs.400">RS.400</option>
                    </select>
                                   

            <button type="submit">Pay Now</button>
        </form>
    </div>
</body>
</html>