<?php
include("connection.php");


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$Payment_ID = $_POST['Payment_ID'];
$Charge = $_POST['Charge'];
$Date = $_POST['Date'];
$Time = $_POST['Time'];
$Customer_ID = $_POST['Customer_ID'];
$Cashier_ID = $_POST['Cashier_ID'];



// Insert data into the database
$sql = "INSERT INTO payment (payment_ID, Charge, date, time, cu_ID, cashier_ID)
        VALUES ('$Payment_ID', '$Charge', '$Date', '$Time', '$Customer_ID', '$Cashier_ID')";

if ($conn->query($sql) === TRUE) {
    header("Location: indexp.php?S=1");
    
} else {
    header("Location: indexp.php?S=2");
   // echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

