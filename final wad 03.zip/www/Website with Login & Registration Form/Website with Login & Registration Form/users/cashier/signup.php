<?php
include("connection.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['submit'])) {
    $fullname = $_POST['fullname'];
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $mnumber = mysqli_real_escape_string($conn, $_POST['mnumber']);
    $password = mysqli_real_escape_string($conn, $_POST['pass']);
    $conpass = mysqli_real_escape_string($conn, $_POST['cpass']);

    $sql = "SELECT * FROM cashier WHERE ca_username='$username'";
    $result = mysqli_query($conn, $sql);
    $count_username = mysqli_num_rows($result);

    $sql = "SELECT * FROM cashier WHERE ca_T_No='$mnumber'";
    $result = mysqli_query($conn, $sql);
    $count_mnumber = mysqli_num_rows($result);

    if ($count_username == 0 && $count_mnumber == 0) {
        if ($password == $conpass) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert_sql = "INSERT INTO cashier(ca_fullname, ca_username, ca_T_No, ca_password) VALUES('$fullname','$username','$mnumber','$hash')";
            $insert_result = mysqli_query($conn, $insert_sql);
            if ($insert_result) {
                header("Location: cashier.php");
                exit();
            } else {
                echo "Insertion error: " . mysqli_error($conn);
            }
        }
    } else {
        if ($count_username > 0) {
            echo '<script>
            window.location.href="cashier.php";
            alert("username already exists!");         
            </script>';
        }

        if ($count_mnumber > 0) {
            echo '<script>
            window.location.href="cashier.php";
            alert("mobilenumber already exists!");         
            </script>';
        }
    }
}
?>
