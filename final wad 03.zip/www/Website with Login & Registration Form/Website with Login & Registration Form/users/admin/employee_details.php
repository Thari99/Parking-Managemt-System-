
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="employee.css">
        <script></script>
        <title>Document</title>
    </head>
    <body>
        <header>
            <h1>Employee Details</h1>
        </header>
        <?php
        include("connection.php");

        ?>
        <main>
            <h2><b>Cashier Details</b></h2>
            <table class="employee_data">
                <tr class="table_row">
                    
                    <th> id</th>
                     <th> Name</th>
                    <th>Username</th>
                    <th>TP</th>
                   
                </tr>
                <?php
                $sql1 = "SELECT cashier_ID, ca_fullname, ca_username, ca_T_No FROM cashier";
                $result1 = $conn->query($sql1);

                if ($result1->num_rows > 0) {
                    while ($row = $result1->fetch_assoc()) {
                        echo "<tr><td>" . $row["cashier_ID"] . "</td><td>" . $row["ca_fullname"] . "</td><td>" . $row["ca_username"] . "</td><td>" . $row["ca_T_No"] ;
                    }
                }
                ?>
                
            </table> 
            <br><br><br><br><br>
            <h2><b>Admin Details</b></h2>
            <table class="employee_data">
                <tr class="table_row">
                    
                    <th> id</th>
                    <th>Name</th>
                    <th> username</th>
                    <th>TP</th>
                    
                   
                </tr>
                <?php
                $sql2 = "SELECT ad_ID , ad_fullname ,ad_username , ad_mobileNo FROM admin ";
                $result2 = $conn->query($sql2);

                if ($result2->num_rows > 0) {
                    while ($row = $result2->fetch_assoc()) {
                        echo "<tr><td>" . $row["ad_ID"] . "</td><td>" . $row["ad_fullname"] . "</td><td>" . $row["ad_username"] . "</td><td>" . $row["ad_mobileNo"] . "</td>";
                    }
                }
                ?>
            </table> 
        </main>
        <footer>
            <p>Developed by <a href="#">Group 6;</a></p>
        </footer>
    </body>
</html>