<?php



// Create a connection
include("connection.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$vehicleId = $_POST['vehicleId'];
$vehicleNumber = $_POST['vehicleNumber'];
$vehicleType = $_POST['vehicleType'];
$date = $_POST['date'];
$time = $_POST['time'];
$customerId = $_POST['customerId'];
$slotId = $_POST['slotId'];
$adId = $_POST['adId'];

// Insert data into the database
$sql = "INSERT INTO vehicle (v_Id, v_no, v_type, date, time, cu_ID, slot_ID, ad_ID)
        VALUES ('$vehicleId', '$vehicleNumber', '$vehicleType', '$date', '$time', '$customerId', '$slotId', '$adId')";

if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>