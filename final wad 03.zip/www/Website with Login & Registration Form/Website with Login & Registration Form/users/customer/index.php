<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Stylesheet.css">
    <script></script>
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Booking Information</h1>
    </header>
    <main>
        <form class="form_class" action="SlotData.php" method="post" >
            <div class="form_div">
                <h4>Select Parking Slot</h4>
                <select name="Slot_ID">
                    <option>Slot 1</option>
                    <option>Slot 2</option>
                    <option>Slot 3</option>
                    <option>Slot 4</option>
                    <option>Slot 5</option>
                    <option>Slot 6</option>
                    <option>Slot 7</option>
                    <option>Slot 8</option>
                    <option>Slot 9</option>
                    <option>Slot 10</option>
                    
                </select><br>
                <h4>Select Parking Lot</h4>
                <select name="Description">
                    <option value="Corner Parking Lot">Corner Parking Lot</option>
                    <option value="Left Parking Lot">Left Parking Lot</option>
                    <option value="Right Parking Lot">Right Parking Lot</option>
                    <option value="Ground Floor">Ground Floor</option>
                    <option value="1st Floor">1st Floor</option>
                    <option value="2nd Floor">2nd Floor</option>
                    
                </select><br>
                <h4>Select Field</h4>
                <select name="Field">
                    <option value="Outside Parking">Outside Parking</option>
                    <option value="Inside Parking">Inside Parking</option>
                </select><br>
                <button class="submit_class" type="submit" >BOOK</button>
            </div>
            <?php
                if (isset($_GET["S"])) {
                    if ($_GET["S"] == 1) {
                        echo "Data inserted successfully";
                    } elseif ($_GET["S"] == 2) {
                        echo "There has been an error";
                    }
                }
            ?>
        </form>
    </main>
    <footer>
        <p>Developed by <a href="#">Group 6</a></p>
    </footer>
</body>
</html>