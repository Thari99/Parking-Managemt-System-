<?php

$admin_id = $_POST['Admin_id'];
$currentPassword = $_POST['current_password'];
$newPassword = $_POST['new_password'];
$confirmNewPassword = $_POST['confirm_password'];

include("connection.php");


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selectQuery = "SELECT Admin_password FROM admin WHERE Admin_id = ?";
$stmt = $conn->prepare($selectQuery);
$stmt->bind_param("s", $admin_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $adminDatabasePassword = $row['Admin_password'];
    
    echo "Entered Password: $currentPassword<br>";
    echo "Stored Hashed Password: $adminDatabasePassword<br>";
    
    if (password_verify($currentPassword,$adminDatabasePassword)) {
        // Validate new password and confirm password match
        if ($newPassword != $confirmNewPassword) {
            echo "New password and confirm password do not match.";
            exit;
        }

        // Hash the new password
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update the password in the database using prepared statement
        $updateQuery = "UPDATE admin SET Admin_password = ? WHERE Admin_id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("ss", $hashedNewPassword, $admin_id);

        if ($updateStmt->execute()) {
            echo "Password updated successfully.";
        } else {
            echo "Error updating password: " . $updateStmt->error;
        }
    } else {
        echo 'Admin username or password incorrect';
    }
} else {
    echo "Admin not found.";
}

// Close the database connection
$conn->close();

?>