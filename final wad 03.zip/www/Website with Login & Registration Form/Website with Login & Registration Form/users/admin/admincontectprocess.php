 
<?php

if (isset($_POST['btn-send'])) 
{
    $Name = $_POST['name'];
    $Username = $_POST['email'];
    $Email = $_POST['email'];
    
    $Message = $_POST['message'];

    if(empty($Name) || empty($Username) || empty($Email ) ||  empty($Message))
    {
        header('location:contect.php?error');
    }

    else {
        $to = "admin@gmail.com";

        if(mail($to,$Name,$Username,$Email,$Message))
        {
            header("location:contect.php?success");
        }
    }

    

}