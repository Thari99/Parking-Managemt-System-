<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Information Form</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
    <h1>Enter Vehicle Information</h1>
    <form action="AddData.php" method="post">
        <label for="vehicleId">Vehicle ID:</label>
        <input type="text" id="vehicleId" name="vehicleId" required><br><br>

        <label for="vehicleNumber">Vehicle Number:</label>
        <input type="text" id="vehicleNumber" name="vehicleNumber" required><br><br>

        <label for="vehicleType">Vehicle Type:</label>
        <input type="text" id="vehicleType" name="vehicleType" required><br><br>

        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required><br><br>

        <label for="time">Time:</label>
        <input type="time" id="time" name="time" required><br><br>

        <label for="customerId">Customer ID:</label>
        <input type="text" id="customerId" name="customerId" required><br><br>

        <label for="slotId">Slot ID:</label>
        <input type="text" id="slotId" name="slotId" required><br><br>

        <label for="adId">Ad ID:</label>
        <input type="text" id="adId" name="adId" required><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
