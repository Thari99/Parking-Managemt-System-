<?php
// Include the database connection
include("connection.php");

// Check if the form was submitted
if (isset($_POST['submit'])) {
    // Sanitize and retrieve user inputs
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['pass'];

    // Retrieve the hashed password from the database based on the provided username
    $sql = "SELECT ad_password FROM admin WHERE ad_username = '$username'";
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful and if a matching user was found
    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $hashed_password = $row['ad_password'];

        // Compare the entered password with the hashed password
        if (password_verify($password, $hashed_password)) {
            // Passwords match, user is logged in
            header("Location: index.php");
            exit();
        } else {
            // Incorrect password
            echo "Passwords do not match.<br>";
        }
    } else {
        // User not found
        echo "User not found.<br>";
    }
}
?>

<!-- Your HTML form for login -->
<form method="POST" action="">
    <input type="text" name="username" placeholder="Username">
    <input type="password" name="pass" placeholder="Password">
    <input type="submit" name="submit" value="Login">
</form>
