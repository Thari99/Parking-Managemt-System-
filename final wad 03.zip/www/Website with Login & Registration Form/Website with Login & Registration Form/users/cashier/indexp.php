
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheets.css">
    <script></script>
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Payment Information</h1>
    </header>
    <main>
        <form class="form_class" action="paymentData.php" method="post" >
            <div class="form_div">
                <label for="Payment_ID">Payment ID</label>
                <input type="text" class="field_class" name="Payment_ID" id="Payment_ID" required> 
                
                <label for="current_password">Charge </label>
                <input type="text" class="field_class" name="Charge" id="Charge" required>
               
                <label for="Charge">Date:</label>
                <input type="date" class="field_class" name="Date" id="Date" required>
                
                <label for="Time">Time:</label>
                <input type="time" class="field_class" name="Time" id="Time" required>
                
                <label for="Customer_ID">Customer ID:</label>
                <input type="text" class="field_class" name="Customer_ID" id="Customer_ID" required>
                
                <label for="Cashier_ID">Cashier ID:</label>
                <input type="text" class="field_class" name="Cashier_ID" id="Cashier_ID" required>
                
                <button class="submit_class" type="submit" >Modify</button>
            </div>
            <?php
                if (isset($_GET["S"])) {
                    if ($_GET["S"] == 1) {
                        echo "Data inserted successfully";
                    } elseif ($_GET["S"] == 2) {
                        echo "There has some error";
                    }
                    
                }
                ?>
        </form>
        
    </main>
    <footer>
        <p>Developed by <a href="#">Group 6;</a></p>
    </footer>
</body>
</html>