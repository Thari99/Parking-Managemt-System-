<!DOCTYPE html>


<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Website with Login & Registration Form</title>
    <link rel="stylesheet" href="style.css" />
    <!-- Unicons -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
  </head>
  <body>
    
    <!-- Header -->
    <header class="header">
      <nav class="nav">
        <a href="#" class="nav_logo">Car Paking System</a>

        <ul class="nav_items">
          <li class="nav_item">
            <a href="#" class="nav_link">Home</a>
            <a href="contect.php" class="nav_link">Contact Us</a>
            <a href="index.php" class="nav_link">parkingslot</a>
            
            <a href="New.php" class="nav_link">payment integration(online)</a>

            
            
          </li>
        </ul>

        <button class="" id="form-open"></button>
      </nav>
    </header>

    

    <!-- Home -->
    <section class="home">
      <div class="form_container">
        <i class="uil uil-times form_close"></i>

        
        
        
        <!-- Login From -->

        <?php
         include("connection.php");

         ?>

        <div class="form login_form">
          <form action="login.php" name="form" method="POST">
            
          <h2>Hi customer!Login</h2>

            <div class="input_box">
              <input type="email" name="username" placeholder="Enter your username" required />
              <i class="uil uil-envelope-alt email"></i>
            </div>
            <div class="input_box">
              <input type="password" name="pass" placeholder="Enter your password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <div class="option_field">
              <span class="checkbox">
                <input type="checkbox" id="check" />
                <label for="check">Remember me</label>
              </span>
              <a href="#" class="forgot_pw">Forgot password?</a>
            </div>

            <input type="submit" id="btn" name="submit" value="Login Now" class="button">

            <div class="login_signup">Don't have an account? <a href="#" id="signup">Signup</a></div>
          </form>
        </div>

        <!-- Signup From -->

       
         <?php
         include("connection.php");

         ?>

        <div class="form signup_form">
          <form action="signup.php" name="form" method="POST">
            <h2>Hi customer!Signup</h2>

            <div class="input_box">
              <input type="text" name="fullname"placeholder="Enter your Full Name" required />
              <i class="fa-solid fa-user"></i>
            </div>

            <div class="input_box">
              <input type="email" name="username" placeholder="Enter your username" required />
              <i class="uil uil-envelope-alt email"></i>
            </div>

            <div class="input_box">
              <input type="text" name="mnumber" placeholder="Enter your mobile number" required />
              <i class="uil uil-envelope-alt email"></i>
            </div>

            <div class="input_box">
              <input type="password" name="pass" placeholder="Create password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>
            <div class="input_box">
              <input type="password" name="cpass" placeholder="Confirm password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <div class="option_field">
              <span class="checkbox">
                <input type="checkbox" id="check" />
                <label for="check">Terms & Conditions</label>
              </span>
            </div>

            <input type="submit" id="btn" value="Signup Now" name="submit"  class="button">

            <div class="login_signup">Already have an account? <a href="#" id="login">Login</a></div>
          </form>
