<?php

session_start();

// Your database connection settings
include("connection.php");


// Function to sanitize input data to prevent SQL injection
function sanitizeInput($input) {
    return htmlspecialchars(trim($input));
}
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Make sure the form was submitted with the required fields
        if (isset($_POST['emp_id'], $_POST['re-emp_id'])) {
            // Sanitize input data
            if (empty($_POST['emp_id']) || empty($_POST['re-emp_id'])) {
                header("Location: RemoveEpmloyee.php?S=3");
            } else {
                $emp_id = sanitizeInput($_POST['emp_id']);
                $re_emp_id = sanitizeInput($_POST['re-emp_id']);

                if ($emp_id !== $re_emp_id) {
                    $error = "Employee IDs do not match.";
                } else {
                    try {
                        // Create a PDO connection
                        $db = new PDO("mysql:host=$host;dbname=$database", $username, $password);
                        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Prepare and execute the DELETE query
                        $deleteQuery = "DELETE FROM cashier WHERE cashier_ID = ?";
                        $deleteStatement = $db->prepare($deleteQuery);
                        $deleteStatement->bindValue(1, $emp_id, PDO::PARAM_INT);
                        $deleteStatement->execute();

                        // Check if any rows were affected by the delete operation
                        $rowsAffected = $deleteStatement->rowCount();

                        if ($rowsAffected > 0) {

                            header("Location: RemoveEpmloyee.php?S=1");
                            exit();
                        } else {
                            header("Location: RemoveEpmloyee.php?S=2");
                        }
                    } catch (PDOException $e) {
                        $error = "An error occurred: " . $e->getMessage();
                    }
                }
            }
        }
    }
} catch (Exception $ex) {
    $error = "An error occurred: " . $e->getMessage();
}
?>
