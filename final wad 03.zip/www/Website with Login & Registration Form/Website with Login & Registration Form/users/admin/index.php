
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1.0">
            <title>Admin Dashboard</title>

            <!-- Montserrat Font -->
            <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

            <!-- Material Icons -->
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

            <!-- Custom CSS -->
            <link rel="stylesheet" href="stylesheet.css" />
        </head>
        <body>
            <?PHP
            include("connection.php");

            ?>
            <div class="grid-container">

                <!-- Header -->

                <!-- End Header -->

                <!-- Sidebar -->
                <aside id="sidebar">
                    <div class="sidebar-title">
                        <div class="sidebar-brand">
                           <span class="">Welcome</span>
                        </div>
                        <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
                    </div>

                    <ul class="sidebar-list">
                        
                        <li class="sidebar_list_item">
                            <a href="employee_details.php">
                                <span class="material-icons-outlined">inventory_2</span> Employee
                            </a>
                        </li>
                        <li class="sidebar_list_item">
                            <a href="customer.php" >
                                <span class="material-icons-outlined">fact_check</span> Customers
                            </a>
                        </li>
                        
                        <li class="sidebar_list_item">
                            <a href="change_password11.php">
                                <span class="material-icons-outlined">settings</span> Change Password
                            </a>
                        </li>
                        <li class="sidebar_list_item">
                            <a href="RemoveEpmloyee.php">
                                <span class="material-icons-outlined">settings</span> Remove Employee
                            </a>
                        </li>
                        <li class="sidebar_list_item">
                            <a href="logout.php">
                                <span class="material-symbols-outlined"></span>Logout 
                            </a>
                        </li>
                    </ul>
                </aside>
                <!-- End Sidebar -->

                <!-- Main -->
                <main class="main-container">
                    <div class="main-title">
                        <p class="font-weight-bold"><h1>Parking Managment System</h1></p>
                    </div>

                    <table style="margin-left: auto;">
                        <tr>
                            <td>

                                <div class="card">
                                    <div class="card-inner">
                                        <p class="text-primary">Total Revenue</p>
                                        <span class="material-icons-outlined text-orange">add_shopping_cart</span>
                                    </div>
                                    <span class="text-primary font-weight-bold"><?php 
                                    $sql3 = "SELECT SUM(charge) AS total_charge FROM payment";
                                    $result = $conn->query($sql3);
                                    $row = $result->fetch_assoc();
                                     $totalCharge = $row['total_charge'];
                                      echo  $totalCharge;
                                    ?></span>
                                </div>
                            </td>
                        </tr>
                    </table>
                    <h2 style="color: black">Vihecle Deatails</h2>
                    <div class="table_data">
                        <table class="vehicle_data">
                            <tr class="table_row">
                                <th>V_id</th>
                                <th>Vehi_Number</th>
                                <th>Vehi_type</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Customer_id</th>
                                <th>Slot_id</th>
                                <th>Admin ID</th>
                            </tr>
                            <?php
                            $sql = "SELECT v_ID ,v_no ,v_type ,date ,time ,cu_ID ,slot_ID ,ad_ID   FROM vehicle ";
                            $result1 = $conn->query($sql);

                            if ($result1->num_rows > 0) {
                                while ($row = $result1->fetch_assoc()) {
                                    echo "<tr><td>" . $row["v_ID"] . "</td><td>" . $row["v_no"] . "</td><td>" . $row["v_type"] . "</td><td>" . $row["date"] . "</td><td>" . $row["time"] . "</td><td>" . $row["cu_ID"] . "</td><td>" . $row["slot_ID"] . "</td><td>". $row["ad_ID"] . "</td>";
                                }
                            }
                            ?>
                        </table>
                        <br><br>
                        <h2 style="color: black">Parking Slot</h2>
                        <table class="slot_data">
                            <tr class="table_row">
                                <th>Slot_Id</th>
                                <th>Description</th>
                                <th>Field</th>
                            </tr>
                            <?php
                            $sql2 = "SELECT slot_ID ,Description ,Field  FROM parkingslot ";
                            $result2 = $conn->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row = $result2->fetch_assoc()) {
                                    echo "<tr><td>" . $row["slot_ID"] . "</td><td>" . $row["Description"] . "</td><td>" . $row["Field"];
                                }
                            }
                            ?>
                        </table>
                    </div>
                </main>
                <!-- End Main -->

            </div>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.35.3/apexcharts.min.js"></script>
            <script src="js/scripts.js"></script>
        </body>
    </html>
</body>
</html>
