<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paymentintegration.css">
    <title>Payment Gateway</title>
</head>
<body>
    <header>
        <h1>Payment Gateway</h1>
    </header>
    <main>
        <form>
            <label for="card-number">Card Number</label>
            <input type="text" id="card-number" name="card-number" required>
            
            <label for="expiry">Expiry Date</label>
            <input type="text" id="expiry" name="expiry" placeholder="MM/YY" required>
            
            <label for="cvv">CVV</label>
            <input type="text" id="cvv" name="cvv" required>
            
            <button type="submit">Pay Now</button>
        </form>
    </main>
    <footer>
        
    </footer>
</body>
</html><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

