
<html>
    <head>
        <meta charset="UTF-8">
        <title>Remove Employee</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="removeEMP.css">
    </head>
    <body>
        <header>
            <h1>Modify Admin Password</h1>
        </header>
        <main>
            <form id="login_form" class="form_class" action="removeEMP.php" method="post">
                <div class="form_div">
                    <label>Employee ID:</label>
                    <input class="field_class" name="emp_id" type="text"  autofocus>

                    <label> Re-Enter Employee ID:</label>
                    <input id="pass" class="field_class" name="re-emp_id" type="text" >
                    <button class="submit_class" type="submit">Delete</button>
                </div>
                <?php
                if (isset($_GET["S"])) {
                    if ($_GET["S"] == 1) {
                        echo "Delete Successful";
                    } elseif ($_GET["S"] == 2) {
                        echo "Can't Find Employee";
                    }
                    elseif ($_GET["S"] == 3) {
                        echo "Please fill in all the required fields.";
                    }
                }
                ?>
            </form>

        </main>

        <footer>
            <p>Developed by <a href="#">Group J&trade;</a></p>
        </footer>

    </body>
</html>
