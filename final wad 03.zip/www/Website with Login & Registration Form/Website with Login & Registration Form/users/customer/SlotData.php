<?php
include("connection.php");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$Slot_ID = $_POST['Slot_ID'];
$Description = $_POST['Description'];
$Field = $_POST['Field'];




// Insert data into the database
$sql = "INSERT INTO parkingslot (Slot_ID, Description, Field)
        VALUES ('$Slot_ID', '$Description', '$Field')";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php?S=1");
    
} else {
    header("Location: index.php?S=2");
   // echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

